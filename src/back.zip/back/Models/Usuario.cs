using System;

namespace CashWiseAPI.Models
{
    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string NomeUsuario { get; set; }
        public string EmailUsuario { get; set; }
        public string SenhaUsuario { get; set; }
        public bool Endividado { get; set; }
        public DateTime DataCriacao { get; set; }
    }
}